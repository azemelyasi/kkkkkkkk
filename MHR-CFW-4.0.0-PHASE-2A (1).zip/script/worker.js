/**
 * MHR CFW 4.0 Phase 2A — Cloudflare Worker exit with independent HMAC-SHA256 verify.
 * Secret: bind Workers Secret AUTH_KEY (optional AUTH_KEY_PREV).
 * Do not hard-code real secrets.
 */

const AUTH_WINDOW_SECONDS = 60;

const EXCLUDED_HEADERS = new Set([
  "host", "connection", "content-length", "transfer-encoding",
  "proxy-connection", "proxy-authorization", "accept-encoding",
  "x-forwarded-for", "x-forwarded-host", "x-forwarded-proto", "x-forwarded-port",
  "x-real-ip", "forwarded", "via", "x-relay-hop",
]);

function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "content-type": "application/json" },
  });
}

function hasCrlf(s) {
  return s.indexOf("\n") >= 0 || s.indexOf("\r") >= 0;
}

function bytesToHex(buf) {
  const u8 = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  let out = "";
  for (let i = 0; i < u8.length; i++) out += u8[i].toString(16).padStart(2, "0");
  return out;
}

async function sha256HexBytes(u8) {
  const dig = await crypto.subtle.digest("SHA-256", u8);
  return bytesToHex(dig);
}

async function sha256HexString(s) {
  const data = new TextEncoder().encode(s);
  return sha256HexBytes(data);
}

async function hmacSha256Hex(secret, message) {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(message));
  return bytesToHex(sig);
}

function constantTimeEqual(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

function normalizeHeaders(h) {
  if (!h || typeof h !== "object" || Array.isArray(h)) throw new Error("invalid_h");
  const out = {};
  for (const rawKey of Object.keys(h)) {
    if (typeof rawKey !== "string" || !rawKey) throw new Error("invalid_header_name");
    if (!/^[0-9a-zA-Z!#$%&'*+.^_`|~-]+$/.test(rawKey)) throw new Error("illegal_header_name");
    const key = rawKey.toLowerCase();
    if (EXCLUDED_HEADERS.has(key)) throw new Error("excluded_header");
    if (Object.prototype.hasOwnProperty.call(out, key)) throw new Error("duplicate_header");
    const val = h[rawKey];
    if (typeof val !== "string") throw new Error("header_value_not_string");
    if (hasCrlf(val)) throw new Error("header_crlf");
    out[key] = val;
  }
  return out;
}

async function computeHh(h) {
  const keys = Object.keys(h).sort();
  let ser = "";
  for (const k of keys) ser += k + ":" + h[k] + "\n";
  return sha256HexString(ser);
}

function buildCanonical(ts, n, m, u, r, ct, hh, bh) {
  return (
    "v:4\n" +
    "ts:" + ts + "\n" +
    "n:" + n + "\n" +
    "m:" + m + "\n" +
    "u:" + u + "\n" +
    "r:" + r + "\n" +
    "ct:" + ct + "\n" +
    "hh:" + hh + "\n" +
    "bh:" + bh + "\n"
  );
}

function b64ToBytes(b64) {
  const bin = atob(b64);
  const u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return u8;
}

async function verifyEnvelope(env, secret, prevSecret) {
  if (!env || typeof env !== "object") throw new Error("invalid_envelope");
  if (!secret) throw new Error("server_misconfigured");
  const required = ["v","ts","n","m","u","r","ct","h","b","bh","hh","alg","sig"];
  for (const k of required) {
    if (!Object.prototype.hasOwnProperty.call(env, k)) throw new Error("missing_" + k);
  }
  if (env.v !== 4) throw new Error("unsupported_version");
  if (env.alg !== "HMAC-SHA256") throw new Error("unsupported_alg");
  if (typeof env.sig !== "string" || !/^[0-9a-f]{64}$/.test(env.sig)) throw new Error("invalid_sig");
  if (typeof env.n !== "string" || !/^[0-9a-f]{32,}$/.test(env.n)) throw new Error("invalid_nonce");
  if (typeof env.ts !== "number" || !Number.isInteger(env.ts) || env.ts < 0) throw new Error("invalid_ts");
  if (typeof env.m !== "string" || env.m !== env.m.toUpperCase() || !env.m) throw new Error("invalid_m");
  if (typeof env.u !== "string" || !env.u || hasCrlf(env.u)) throw new Error("invalid_u");
  if (env.r !== 0 && env.r !== 1) throw new Error("invalid_r");
  if (typeof env.ct !== "string" || hasCrlf(env.ct)) throw new Error("invalid_ct");
  if (typeof env.hh !== "string" || !/^[0-9a-f]{64}$/.test(env.hh)) throw new Error("invalid_hh");
  if (typeof env.bh !== "string" || (env.bh !== "" && !/^[0-9a-f]{64}$/.test(env.bh))) throw new Error("invalid_bh");

  const now = Math.floor(Date.now() / 1000);
  if (Math.abs(now - env.ts) > AUTH_WINDOW_SECONDS) throw new Error("ts_expired");

  const h = normalizeHeaders(env.h);
  if ((await computeHh(h)) !== env.hh) throw new Error("hh_mismatch");

  let rawBody = null;
  if (env.b === null || env.b === undefined) {
    if (env.bh !== "") throw new Error("bh_mismatch");
  } else {
    if (typeof env.b !== "string") throw new Error("invalid_b");
    rawBody = b64ToBytes(env.b);
    const bhCalc = await sha256HexBytes(rawBody);
    if (bhCalc !== env.bh) throw new Error("bh_mismatch");
  }

  const canonical = buildCanonical(env.ts, env.n, env.m, env.u, env.r, env.ct, env.hh, env.bh);
  let expected = await hmacSha256Hex(secret, canonical);
  let ok = constantTimeEqual(expected, env.sig);
  if (!ok && prevSecret) {
    expected = await hmacSha256Hex(prevSecret, canonical);
    ok = constantTimeEqual(expected, env.sig);
  }
  if (!ok) throw new Error("sig_invalid");

  return { m: env.m, u: env.u, r: env.r, ct: env.ct, h, rawBody };
}

export default {
  async fetch(request, env) {
    try {
      if (request.headers.get("x-relay-hop") === "1") {
        return json({ e: "loop detected" }, 508);
      }

      const secret = (env && env.AUTH_KEY) || "";
      const prevSecret = (env && env.AUTH_KEY_PREV) || "";

      let bodyText;
      try {
        bodyText = await request.text();
      } catch (e) {
        return json({ e: "invalid_body" }, 400);
      }

      let req;
      try {
        req = JSON.parse(bodyText);
      } catch (e) {
        return json({ e: "invalid_json" }, 400);
      }

      // Phase 2A: require signed envelope
      if (!req || req.v !== 4 || !req.sig) {
        return json({ e: "unauthorized", detail: "signed_envelope_required" }, 401);
      }

      let verified;
      try {
        verified = await verifyEnvelope(req, secret, prevSecret);
      } catch (err) {
        return json({ e: "unauthorized", detail: String(err.message || err) }, 401);
      }

      // Destination strictly from verified envelope
      let targetUrl;
      try {
        targetUrl = new URL(verified.u);
      } catch (e) {
        return json({ e: "bad url" }, 400);
      }
      if (targetUrl.protocol !== "http:" && targetUrl.protocol !== "https:") {
        return json({ e: "bad url" }, 400);
      }

      const headers = new Headers();
      for (const [k, v] of Object.entries(verified.h)) {
        headers.set(k, v);
      }
      if (verified.ct) headers.set("content-type", verified.ct);
      headers.set("x-relay-hop", "1"); // operational, not signed

      const fetchOptions = {
        method: verified.m,
        headers,
        redirect: verified.r === 0 ? "manual" : "follow",
      };
      if (verified.rawBody) {
        fetchOptions.body = verified.rawBody;
      }

      const resp = await fetch(targetUrl.toString(), fetchOptions);
      const buffer = await resp.arrayBuffer();
      const uint8 = new Uint8Array(buffer);
      let binary = "";
      const chunkSize = 0x8000;
      for (let i = 0; i < uint8.length; i += chunkSize) {
        binary += String.fromCharCode.apply(null, uint8.subarray(i, i + chunkSize));
      }
      const base64 = btoa(binary);
      const responseHeaders = {};
      resp.headers.forEach((v, k) => { responseHeaders[k] = v; });
      return json({ s: resp.status, h: responseHeaders, b: base64 });
    } catch (err) {
      return json({ e: String(err) }, 500);
    }
  },
};
